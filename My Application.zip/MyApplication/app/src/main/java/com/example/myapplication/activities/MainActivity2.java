package com.example.myapplication.activities;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

public class MainActivity2 extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String name = getIntent().getStringExtra("NAME");
        String description = getIntent().getStringExtra("DESCRIPTION");
        String content = getIntent().getStringExtra("CONTENT");
        int image = getIntent().getIntExtra("IMAGE",0);

        TextView nameTextView = findViewById(R.id.Titletv);
        TextView descTextView = findViewById(R.id.desctv);
        TextView contentTextView = findViewById(R.id.contenttv);
        ImageView imgView = findViewById(R.id.imgtv);

        nameTextView.setText(name);
        descTextView.setText(description);
        contentTextView.setText(content);
        imgView.setImageResource(image);

    }
}
