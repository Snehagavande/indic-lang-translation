package com.example.myapplication.activities;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import  androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

import java.util.ArrayList;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.MyViewHolder> implements Filterable {
   private final RecyclerViewInterface recyclerViewInterface;

    Context context;
    ArrayList<Model> models;
    ArrayList<Model> backup;


    public RecycleViewAdapter(Context context, ArrayList<Model> models,RecyclerViewInterface recyclerViewInterface){
        this.context = context;
        this.models = models;
        backup=new ArrayList<>(models);
        this.recyclerViewInterface= recyclerViewInterface;
    }

    @NonNull
    @Override
    public RecycleViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //This is where you inflate the layout (Giving A look to out rows)
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recycle_view_row, parent, false);
        return new RecycleViewAdapter.MyViewHolder(view,recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull RecycleViewAdapter.MyViewHolder holder, int position) {
       //assigning values to view we created in the recycle_view_row layout file
        // based on the position of the recycle view
        holder.tvname.setText(models.get(position).getModelname());
        holder.tvdes.setText(models.get(position).getModeldes());
        holder.imageView.setImageResource(models.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        //the recycler view just want to know the number of items you want display
        return models.size();
    }

    @Override
    public Filter getFilter() {
        return filter;
    }

    Filter filter=new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence keyword) {

            ArrayList<Model>filtereddata = new ArrayList<>();

            if(keyword.toString().isEmpty())
                filtereddata.addAll(backup);
            else {
                for (Model obj : backup) {
                    if (obj.getModelname().toString().toLowerCase().contains(keyword.toString().toLowerCase())) {
                        filtereddata.add(obj);
                    }
                }
            }
            FilterResults results=new FilterResults();
            results.values=filtereddata;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {

            models.clear();
            models.addAll((ArrayList<Model>)results.values);
            notifyDataSetChanged();

        }
    };




    public static class MyViewHolder extends RecyclerView.ViewHolder{
        //grabbing the views from our recycler_view_row layout file
        //Kinda like in the onCreate method

        ImageView imageView;
        TextView tvname, tvdes;
        public MyViewHolder(@NonNull View itemView,RecyclerViewInterface recyclerViewInterface) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageView2);
            tvname = itemView.findViewById(R.id.textView5);
            tvdes = itemView.findViewById(R.id.textView6);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(recyclerViewInterface != null){
                        int pos = getAdapterPosition();

                        if(pos != RecyclerView.NO_POSITION){
                            recyclerViewInterface.onItemClick(pos);
                        }
                    }
                }
            });
        }
    }


}
