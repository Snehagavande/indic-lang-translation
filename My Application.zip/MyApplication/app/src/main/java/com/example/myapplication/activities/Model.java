package com.example.myapplication.activities;

public class Model {
    String modelname;
    String modeldes;

    String modelcontent;
    int image;

    public Model(String modelname, String modeldes, String modelcontent, int image) {
        this.modelname = modelname;
        this.modeldes = modeldes;
        this.image = image;
        this.modelcontent= modelcontent;
    }

    public String getModelname() {
        return modelname;
    }

    public String getModelcontent() {
        return modelcontent;
    }

    public String getModeldes() {
        return modeldes;
    }

    public int getImage() {
        return image;
    }
}
