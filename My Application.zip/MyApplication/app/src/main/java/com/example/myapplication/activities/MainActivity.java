package com.example.myapplication.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.ColorSpace;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.myapplication.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements RecyclerViewInterface {

    ArrayList<Model> models = new ArrayList<>();
    RecycleViewAdapter adapter;
    int[] mimages= {R.drawable.traditional,R.drawable.shirt,R.drawable.bag,
            R.drawable.watch,R.drawable.accessories,R.drawable.jeans,
            R.drawable.kids,R.drawable.banner1,R.drawable.heels};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.mRecycleView);

        setUpModels();

        adapter = new RecycleViewAdapter(this,
                models,this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void setUpModels(){
        String[] MNames = getResources().getStringArray(R.array.category);
        String[] MDes = getResources().getStringArray(R.array.Brand);
        String[] MCon = getResources().getStringArray(R.array.Content);

        for(int i=0; i<MNames.length; i++){
            models.add(new Model(MNames[i],MDes[i],MCon[i],mimages[i]));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.mainmenu,menu);
        MenuItem item=menu.findItem(R.id.search_menu);

        SearchView searchView=(SearchView) item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public void onItemClick(int Position) {
        Intent intent = new Intent(MainActivity.this,MainActivity2.class);

        intent.putExtra("NAME", models.get(Position).getModelname());
        intent.putExtra("DESCRIPTION", models.get(Position).getModeldes());
        intent.putExtra("CONTENT", models.get(Position).getModelcontent());
        intent.putExtra("IMAGE", models.get(Position).getImage());
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}