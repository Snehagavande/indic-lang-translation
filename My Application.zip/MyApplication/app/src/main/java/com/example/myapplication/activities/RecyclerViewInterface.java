package com.example.myapplication.activities;

 interface RecyclerViewInterface {
    void onItemClick(int Position);
}
